#include "IInterlockedLong.h"

// all functions are inlined
