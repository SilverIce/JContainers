#include "GlobalLocks.h"
#include "common/ICriticalSection.h"

ICriticalSection	g_loadGameLock;
