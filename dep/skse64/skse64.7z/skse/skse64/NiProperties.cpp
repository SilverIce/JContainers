#include "skse64/NiProperties.h"
