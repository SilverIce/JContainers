#include "skse64/NiTextures.h"

RelocAddr<_CreateSourceTexture> CreateSourceTexture(0x00C92040);
RelocAddr<_LoadTexture> LoadTexture(0x013BC9D0);
