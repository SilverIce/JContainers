#include "skse64/NiTextures.h"

RelocAddr<_CreateSourceTexture> CreateSourceTexture(0x00C91030);
RelocAddr<_LoadTexture> LoadTexture(0x013BBAB0);
