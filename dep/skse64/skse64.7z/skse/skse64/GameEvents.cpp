#include "GameEvents.h"

// 614D2151B14D0D61E7DA7088CAB85DB111E2E0D3+1B
RelocAddr<_GetEventDispatcherList> GetEventDispatcherList(0x00195E20);

//EventDispatcher<BGSFootstepEvent>* g_footstepEventDispatcher = (EventDispatcher<BGSFootstepEvent>*) 0x01B2E9C0;

// Story based events
//EventDispatcher<TESHarvestEvent::ItemHarvested>* g_harvestEventDispatcher = (EventDispatcher<TESHarvestEvent::ItemHarvested>*) 0x012E5A74;
// Event	ActorKill																													0xDEADBEEF
// Event	ActorItemEquipped																											0xDEADBEEF
// Event	Pickpocket																													0xDEADBEEF
// Event	BooksRead																													0xDEADBEEF
//EventDispatcher<LevelIncrease::Event>* g_levelIncreaseEventDispatcher = (EventDispatcher<LevelIncrease::Event>*) 0x01B39804;
// Event	SkillIncrease																												0xDEADBEEF
// Event	WordLearned																													0xDEADBEEF
// Event	WordUnlocked																												0xDEADBEEF
// Event	Inventory																													0xDEADBEEF
// Event	Bounty																														0xDEADBEEF
// Event	QuestStatus																													0xDEADBEEF
// Event	ObjectiveState																												0xDEADBEEF
// Event	Trespass																													0xDEADBEEF
// Event	FinePaid																													0xDEADBEEF
// Event	HoursPassed																													0xDEADBEEF
// Event	DaysPassed																													0xDEADBEEF
// Event	DaysJailed																													0xDEADBEEF
// Event	CriticalHitEvent																											0xDEADBEEF
// Event	DisarmedEvent																												0xDEADBEEF
// Event	ItemsPickpocketed																											0xDEADBEEF
// Event	ItemSteal																													0xDEADBEEF
// Event	ItemCrafted																													0xDEADBEEF
// Event	LocationDiscovery																											0xDEADBEEF
// Event	Jailing																														0xDEADBEEF
// Event	ChestsLooted																												0xDEADBEEF
// Event	TimesTrained																												0xDEADBEEF
// Event	TimesBartered																												0xDEADBEEF
// Event	ContractedDisease																											0xDEADBEEF
// Event	SpellsLearned																												0xDEADBEEF
// Event	DragonSoulGained																											0xDEADBEEF
// Event	SoulGemsUsed																												0xDEADBEEF
// Event	SoulsTrapped																												0xDEADBEEF
// Event	PoisonedWeapon																												0xDEADBEEF
// Event	ShoutAttack																													0xDEADBEEF
// Event	JailEscape																													0xDEADBEEF
// Event	GrandTheftHorse																												0xDEADBEEF
// Event	AssaultCrime																												0xDEADBEEF
// Event	MurderCrime																													0xDEADBEEF
// Event	LocksPicked																													0xDEADBEEF
// Event	LocationCleared																												0xDEADBEEF
// Event	ShoutMastered																												0xDEADBEEF
