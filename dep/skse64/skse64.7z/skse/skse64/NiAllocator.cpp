#include "skse64/NiAllocator.h"

const _NiAllocate	NiAllocate = (_NiAllocate)0x00000000;
const _NiFree		NiFree = (_NiFree)0x00000000;
