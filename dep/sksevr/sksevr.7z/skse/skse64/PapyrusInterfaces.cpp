#include "skse64/PapyrusInterfaces.h"

// 7C4C122775755268EFE5870BA66247C63E1A2BEA+12
RelocPtr <IObjectHandlePolicy*> g_objectHandlePolicy(0x0341D808);
