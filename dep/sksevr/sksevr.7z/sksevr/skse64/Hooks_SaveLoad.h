#pragma once

void Hooks_SaveLoad_Commit(void);
