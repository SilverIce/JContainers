#pragma once

void Hooks_VR_Init();
void Hooks_VR_Commit();